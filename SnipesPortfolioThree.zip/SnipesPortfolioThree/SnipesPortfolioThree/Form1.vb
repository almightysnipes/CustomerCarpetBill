﻿Public Class Form1
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim cost As Double = CInt(TextBox1.Text)
        Select Case cost
            Case 1
                ListBox1.Items.Add(("Cost per Sqaure Yard: " & "18.50"))
                ListBox1.Items.Add(("Labor per Square Yard: " & "3.50"))
                ListBox1.Items.Add(("Floor Preperation Cost: " & "38.50"))
                ListBox1.Items.Add(("Cost for Carpet: " & 17 * 18.5))
                ListBox1.Items.Add(("Cost for Labor: " & 17 * 3.5 + 38.5))
                ListBox1.Items.Add(("Discount on Carpet: " & 314.5 * 0.02))
                ListBox1.Items.Add(("Tax on Carpet: " & "12.33"))
                ListBox1.Items.Add(("Charge to Customer: " & 314.5 + 98.0 + 6.29))
            Case 2
                ListBox1.Items.Add(("Cost per Sqaure Yard: " & "24.95"))
                ListBox1.Items.Add(("Labor per Square Yard: " & "2.95"))
                ListBox1.Items.Add(("Floor Preperation Cost: " & "0.00"))
                ListBox1.Items.Add(("Cost for Carpet: " & 40 * 24.95))
                ListBox1.Items.Add(("Cost for Labor: " & 40 * 2.95 + 0.00))
                ListBox1.Items.Add(("Discount on Carpet: " & 998.0 * 0.14))
                ListBox1.Items.Add(("Tax on Carpet: " & "34.33"))
                ListBox1.Items.Add(("Charge to Customer: " & 998.0 + 118.0 + 139.72))
            Case 3
                ListBox1.Items.Add(("Cost per Sqaure Yard: " & "16.80"))
                ListBox1.Items.Add(("Labor per Square Yard: " & "3.25"))
                ListBox1.Items.Add(("Floor Preperation Cost: " & "57.95"))
                ListBox1.Items.Add(("Cost for Carpet: " & 23 * 16.8))
                ListBox1.Items.Add(("Cost for Labor: " & 23 * 3.25 + 57.95))
                ListBox1.Items.Add(("Discount on Carpet: " & 386.4 * 0.00))
                ListBox1.Items.Add(("Tax on Carpet: " & "15.46"))
                ListBox1.Items.Add(("Charge to Customer: " & 386.4 + 137.7 + 0))
            Case 4
                ListBox1.Items.Add(("Cost per Sqaure Yard: " & "21.25"))
                ListBox1.Items.Add(("Labor per Square Yard: " & "0.00"))
                ListBox1.Items.Add(("Floor Preperation Cost: " & "80.00"))
                ListBox1.Items.Add(("Cost for Carpet: " & 26 * 21.25))
                ListBox1.Items.Add(("Cost for Labor: " & 26 * 0.00 + 80.0))
                ListBox1.Items.Add(("Discount on Carpet: " & 552.5 * 0.00))
                ListBox1.Items.Add(("Tax on Carpet: " & "22.10"))
                ListBox1.Items.Add(("Charge to Customer: " & 552.5 + 80.0 + 0))
        End Select
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        TextBox1.Text = ""
        ListBox1.Items.Clear()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Me.Close()
    End Sub
End Class
